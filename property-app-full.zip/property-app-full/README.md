# Property App
Instructions to run locally
